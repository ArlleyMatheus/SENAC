<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'

</script>

<template>
  <header>
  
  </header>
  <RouterView />
  <footer>  
        <nav>
          <RouterLink to="/">Home</RouterLink>
        <br>
        <RouterLink to="/cadastro">Cadastro</RouterLink>
        <br>
        <RouterLink to="/login">Login</RouterLink>
      </nav>
  </footer>
</template>

<style scoped>
footer{
  text-align: right;
}

</style>