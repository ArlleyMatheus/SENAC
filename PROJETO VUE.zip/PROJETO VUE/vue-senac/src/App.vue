<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <RouterView />
  <footer>  
    <div class="wrapper">
          <nav>
        <RouterLink to="/">Home</RouterLink>
        <br>
        <RouterLink to="/cadastro">Cadastro</RouterLink>
        <br>
        <RouterLink to="/login">Login</RouterLink>
      </nav>
    </div>
  </footer>
</template>

