<template>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site de agendamento</title>
  </head>
  <header>
    <div class="Logo">
      <img src="../assets/imagens/Cadastro/LOGO SITE.png" width="300" height="100">
    </div>
  </header>
  <body>
    <div class="container">
      <div class="Formulario">
        <form action="" style="border-radius:30%">
          <label for="name">Digite o seu nome</label><br>
          <input type="text" id="fname" name="fname" value="Arlley"><br>
          <label for="name">Digite o seu nome</label><br>
          <input type="text" id="fname" name="fname" value="Arlley"><br>
          <label for="name">Digite o seu nome</label><br>
          <input type="text" id="fname" name="fname" value="Arlley"><br>
          <label for="name">Digite o seu nome</label><br>
          <input type="text" id="fname" name="fname" value="Arlley"><br>
          <label for="name">Digite o seu nome</label><br>
          <input type="text" id="fname" name="fname" value="Arlley"><br>
          <label for="name">Digite o seu nome</label><br>
          <input type="text" id="fname" name="fname" value="Arlley"><br>
        </form>
        <h1>esta é uma div</h1>
      </div>
      <img class="img_banner" src="../assets/imagens/Cadastro/fundo_de_tela_cadastro.png">
    </div>
  </body>
</template>


  <style scoped>
  .container{
    display: grid;
    place-items: center;


  }
  .Formulario{
      background-color: rgba(224, 176, 247, 1);
      position:absolute;
      width: 30%;
      height: 80%;
  }
  .img_banner{
    width:100%;
    height:auto;
  }

  .Logo{
    padding-left:10px;
    padding-top: 10px;
  }
  </style>
