<template>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site de agendamento</title>
  </head>
  <header>
    <div class="Logo">
      <RouterLink to="/cadastro"><img src="../assets/imagens/Cadastro/LOGO SITE.png" width="300" height="100"></RouterLink>      
    </div>
    <RouterLink class="botao1" to="/"><button >Voltar</button></RouterLink><br>
  </header>
  <body>
    <div class="container">
      <div class="Formulario">
        <form action="" style="border-radius:30%">
          <h1>Cadastro</h1>
          <label for="name">Nome Completo </label><br>
          <input type="text" id="fname" name="fname" value=""><br>
          <label for="name">CPF</label><br>
          <input type="text" id="fname" name="fname" value=""><br>
          <label for="name">Email</label><br>
          <input type="text" id="fname" name="fname" value=""><br>
          <label for="name">Senha</label><br>
          <input type="text" id="fname" name="fname" value=""><br>
          <label for="name">Confirmar Senha</label><br>
          <input type="text" id="fname" name="fname" value=""><br>
          <RouterLink class="botao" to="/cadastro"><button >Cadastro</button></RouterLink><br>
          <RouterLink class="botao" to="/login"><button >Login</button></RouterLink>
          
        </form>
      </div>
      <img class="img_banner" src="../assets/imagens/Cadastro/fundo_de_tela_cadastro.png">
    </div>
  </body>
</template>


  <style scoped>
  .container{
    display: grid;
    place-items: center;
    text-align: center;


  }
  .Formulario{
    background-color: rgba(224, 176, 247, 1);
    position:absolute;
    width:40%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center ;
    height: 90vh;
    margin:1Opx 20px ;
    margin-top: 30px;
    border-radius:20px ;
    text-align: left;
  }
  .img_banner{
    width:100%;
    height:auto;
  }
  
  .Logo{
    padding-left:10px;
    padding-top: 10px;
  }
  form input ,form textarea {
    outline : unset ;
    padding : 21px ;
    width : 600px ;
    border : 1px ;
    text-decoration: solid;
    border-radius: 20px;
    
  }
  
  form label {
    margin-left:20px;
    justify-content: left;
    align-items: left;
  }
  form {
    margin:3Opx 3px ;
    margin-top: 80px;
    color: white ;
    font-size : 30px;
    
  }
  button{
    height: 60px;
    width:250px;
    font-size: 40px;
    color:rgba(189, 85, 237, 1);
    background-color: white;
    border-radius:20px ;
    align-items: center;
    
  }
  .botao1{
    text-align: right;
    justify-content: right;
    display: flex;
    color:rgba(189, 85, 237, 1);
    text-decoration: none;
    margin-top: 10px;
    height: 50%;   
  }
  .botao{
    text-align: center;
    justify-content: center;
    display: flex;
    color:rgba(189, 85, 237, 1);
    text-decoration: none;
  }
  </style>
