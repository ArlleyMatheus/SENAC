<script setup lang="ts">

</script>

<template>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Site de agendamento</title>
</head>
<header>
  <div>
    <img class="Logo" src="../assets/imagens/Home/LOGO SITE.png"> 
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Sobre Nós</a></li>
        <li><a href="#">Contato</a></li>
      </ul>
    </nav>
  </div> 
</header>
<body>
  <img class="Carrosel"  src="../assets/imagens/Home/Carrosel_imagem_1.png" alt="">
  <h2>Somos uma empresa de Tecnologia voltada  a desenvolver um software que  funciona de maneira on line, disponibilizando um sistema de agendamento que pode ser integrado com sistemas 
    de hospitais, cais e Upas. </h2>
</body>

</template>

<style scoped>
nav ul{
  list-style: none;
  margin: 20px;
  float: right;
}
nav ul li{
  float: left;
}
nav ul li a{
  display: block;
  margin-right: 50px;
  padding-bottom: 100px;

}
.Logo{
  width:auto;
  margin:25px;
}


.Carrosel{
  width:100%;  
  height:100%;
}


</style>