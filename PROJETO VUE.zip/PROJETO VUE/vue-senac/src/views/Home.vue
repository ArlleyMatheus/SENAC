<script setup lang="ts">

</script>

<template>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Site de agendamento</title>
</head>
<header>
  <div class="cabecalho">
    <img class="Logo" src="../assets/imagens/Home/LOGO SITE.png"> 
  
      <ul>
        <li><RouterLink to="/">Home</RouterLink></li>
        <li><RouterLink to="/cadastro">Cadastro</RouterLink></li>
        <li><RouterLink to="/login">Login</RouterLink></li>
      </ul>
      <div class="Botao">
        <button>Login</button><br>
        <button>Cadastrar</button>
      </div>

  </div> 
</header>
<body>
  <img class="Carrosel"  src="../assets/imagens/Home/Carrosel_imagem_1.png" alt="">
  <div class='texto'>
    <h2>Somos uma empresa de Tecnologia voltada  a desenvolver um software que  funciona de maneira on line, disponibilizando um sistema de agendamento que pode ser integrado com sistemas 
      de hospitais, cais e Upas. </h2>
  </div>
</body>

</template>

<style scoped>
.cabecalho{
  display: flex;
  align-items:center;
  font-size: 30px;
}
ul{
  padding-top:100px;
  list-style: none;
  margin: 20px;
  float: right;
}
ul li{
  float: left;
}
ul li a{
  display: block;
  margin-right: 50px;
  padding-bottom: 100px;
  text-decoration: none;
  color: white;

}
.Logo{
  width:auto;
  margin:25px;
}


.Carrosel{
  width:100%;  
  height:100%;
}
h2{
  color:rgba(0, 112, 168, 1);
  font-size:35px
}
.texto{
  display:center;
  align-items:center;
  padding:50px 90px
}
.botao{
  display: flex;
  align-items:left;
}

</style>