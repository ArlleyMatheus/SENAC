<template>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site de agendamento</title>
  </head>
  <header>
    <div class="Logo">
      <img src="../assets/imagens/Cadastro/LOGO SITE.png" width="300" height="100">
    </div>
  </header>
  <body>
    <div class="container">
      <div class="Formulario">
        <form action="" style="border-radius:30%">
          <label for="name">Digite seu CPF</label><br>
          <input type="text" id="fname" name="fname" value=""><br>
          <label for="name">Digite sua Senha</label><br>
          <input type="text" id="fname" name="fname" value=""><br>         
          <button>Entrar</button><br>
          <RouterLink to="/cadastro"><button >Cadastro</button></RouterLink>
        </form>
      </div>
      <img class="img_banner" src="../assets/imagens/Cadastro/fundo_de_tela_cadastro.png">
    </div>
  </body>
</template>


  <style scoped>
  .container{
    display: grid;
    place-items: center;
    text-align: center;


  }
  .Formulario{
    background-color: rgba(224, 176, 247, 1);
    position:absolute;
    width: 40%;
    height: 80%;
    display: fliex;
    align-items: center;
    justify-content: center ;
    height: 80vh;
    margin:2Opx 20px ;
    margin-top: 30px;
    border-radius:20px ;
  }
  .img_banner{
    width:100%;
    height:auto;
  }
  
  .Logo{
    padding-left:10px;
    padding-top: 10px;
  }
  form input ,form textarea {
    outline : unset ;
    padding : 20px ;
    width : 300px ;
    border : Ipx ;
    text-decoration: solid;
    border-radius: 20px;
    
  }
  
  form label {
    margin-left:20px;
  }
  form {
    margin:2Opx 3px ;
    margin-top: 150px;
    color: white ;
    font-size : 30px;
    
  }
  button{
    height: 60px;
    width:250px;
    font-size: 40px;
    color:rgba(189, 85, 237, 1);
    background-color: white;
    border-radius:20px ;
    
  }
  </style>
